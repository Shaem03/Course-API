<?php

include(APPPATH . "libraries\Rest_controller.php");

class Authenticate extends Rest_controller {

    public function __construct() {
        parent::Rest_controller();

        $this->load->model("Auth_m");
    }

    /* step1:Authentication */

    function authenticate_post() {

        $raw_post = file_get_contents('php://input');
        $message = $this->Auth_m->auth_post($raw_post);
        $this->response($message);
    }

}
