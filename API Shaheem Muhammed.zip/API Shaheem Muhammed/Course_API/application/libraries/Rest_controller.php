<?php

class Rest_controller extends CI_Controller {

    var $request_method;
    var $id;
    var $method;
    var $_formats = array(
        'xml' => 'application/xml',
        'json' => 'application/json',
        'html' => 'application/html'
    );

    public function __construct() {

        parent::Rest_controller();
        //$this->load->model("Leadmodel");
    }

    function Rest_controller() {
        parent::__construct();

        $this->_CI = &get_instance();
        // Load the inflector helper
        $this->_CI->load->helper('inflector');
        $this->request_method = $_SERVER['REQUEST_METHOD'];
        $this->id = (int) $this->uri->segment("3");
        $this->method = $this->uri->segment("2");
    }

    function _remap() {
        if ($this->method != "index") {
            if ($this->id == NULL) {

                switch ($this->request_method) {
                    case "GET":
                        $method = $this->method . "_get";

                        if (method_exists($this, $method)) {
                            $this->{$this->method . "_get"}();
                        } else {
                            //$message = array('response' => '404');
                            $message = array(
                                'status' => false,
                                'message' => 'Invalid API',
                                'response_code' => 404);


                            $this->response($message);
                        }


                        break;
                    case "POST":
                        //check  the method from outer world
                        $method = $this->method . "_post";
                        if (method_exists($this, $method)) {
                            $this->{$this->method . "_post"}();
                        } else {

                            $message = array(
                                'status' => false,
                                'message' => 'Invalid API',
                                'response_code' => 404);

                            $this->response($message);
                        }

                        break;
                    case "DELETE":
                        $this->{$this->method . "_delete"}();
                        break;
                }
            } else {
                switch ($this->request_method) {
                    case "GET":
                        $this->{$this->method . "_get"}($this->id);
                        break;

                    case "PUT":
                        $this->{$this->method . "_put"}($this->id);
                        break;
                    case "DELETE":
                        $this->{$this->method . "_delete"}($this->id);
                        break;
                }
            }
        } else {
            $this->index();
        }
    }

    function response($data, $http_status = 200, $format = 'json') {
        if (empty($data)) {
            $this->output->set_status_header(404);
            return;
        }
        $this->output->set_status_header($http_status);
        if (method_exists($this, '_format_' . $format)) {

            $this->output->set_header('Content-type: ' . $this->_formats[$format]);

            $final_data = $this->{'_format_' . $format}($data);
            $this->output->set_output($final_data);
        } else {
            $this->output->set_output($data);
        }
    }

    /**
     * Format data as XML
     *
     * @param mixed|NULL $data Optional data to pass, so as to override the data passed
     * to the constructor
     * @param NULL $structure
     * @param string $basenode
     * @return mixed
     */
    public function _format_xml($data = NULL, $structure = NULL, $basenode = 'xml') {
        if ($data === NULL && func_num_args() === 0) {
            $data = $this->_data;
        }

        // turn off compatibility mode as simple xml throws a wobbly if you don't.
        if (ini_get('zend.ze1_compatibility_mode') == 1) {
            ini_set('zend.ze1_compatibility_mode', 0);
        }

        if ($structure === NULL) {
            $structure = simplexml_load_string("<?xml version='1.0' encoding='utf-8'?><$basenode />");
        }

        // Force it to be something useful
        if (is_array($data) === FALSE && is_object($data) === FALSE) {
            $data = (array) $data;
        }

        foreach ($data as $key => $value) {

            //change false/true to 0/1
            if (is_bool($value)) {
                $value = (int) $value;
            }

            // no numeric keys in our xml please!
            if (is_numeric($key)) {
                // make string key...
                $key = (singular($basenode) != $basenode) ? singular($basenode) : 'item';
            }

            // replace anything not alpha numeric
            $key = preg_replace('/[^a-z_\-0-9]/i', '', $key);

            if ($key === '_attributes' && (is_array($value) || is_object($value))) {
                $attributes = $value;
                if (is_object($attributes)) {
                    $attributes = get_object_vars($attributes);
                }

                foreach ($attributes as $attribute_name => $attribute_value) {
                    $structure->addAttribute($attribute_name, $attribute_value);
                }
            }
            // if there is another array found recursively call this function
            elseif (is_array($value) || is_object($value)) {
                $node = $structure->addChild($key);

                // recursive call.
                $this->_format_xml($value, $node, $key);
            } else {
                // add single node.
                $value = htmlspecialchars(html_entity_decode($value, ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8');

                $structure->addChild($key, $value);
            }
        }

        return $structure->asXML();
    }

    function _format_json($data) {
        return json_encode($data);
    }

    /**
     * Format data as HTML
     *
     * @param mixed|NULL $data Optional data to pass, so as to override the data passed
     * to the constructor
     * @return mixed
     */
    public function _format_html($data = NULL) {
        // If no data is passed as a parameter, then use the data passed
        // via the constructor
        if ($data === NULL && func_num_args() === 0) {
            $data = $this->_data;
        }

        // Cast as an array if not already
        if (is_array($data) === FALSE) {
            $data = (array) $data;
        }

        // Check if it's a multi-dimensional array
        if (isset($data[0]) && count($data) !== count($data, COUNT_RECURSIVE)) {
            // Multi-dimensional array
            $headings = array_keys($data[0]);
        } else {
            // Single array
            $headings = array_keys($data);
            $data = [$data];
        }

        // Load the table library
        $this->_CI->load->library('table');

        $this->_CI->table->set_heading($headings);

        foreach ($data as $row) {
            // Suppressing the "array to string conversion" notice
            // Keep the "evil" @ here
            $row = @array_map('strval', $row);

            $this->_CI->table->add_row($row);
        }

        return $this->_CI->table->generate();
    }

    /**
     * @link http://www.metashock.de/2014/02/create-csv-file-in-memory-php/
     * @param mixed|NULL $data Optional data to pass, so as to override the data passed
     * to the constructor
     * @param string $delimiter The optional delimiter parameter sets the field
     * delimiter (one character only). NULL will use the default value (,)
     * @param string $enclosure The optional enclosure parameter sets the field
     * enclosure (one character only). NULL will use the default value (")
     * @return string A csv string
     */
    public function _format_csv($data = NULL, $delimiter = ',', $enclosure = '"') {
        // Use a threshold of 1 MB (1024 * 1024)
        $handle = fopen('php://temp/maxmemory:1048576', 'w');
        if ($handle === FALSE) {
            return NULL;
        }

        // If no data is passed as a parameter, then use the data passed
        // via the constructor
        if ($data === NULL && func_num_args() === 0) {
            $data = $this->_data;
        }

        // If NULL, then set as the default delimiter
        if ($delimiter === NULL) {
            $delimiter = ',';
        }

        // If NULL, then set as the default enclosure
        if ($enclosure === NULL) {
            $enclosure = '"';
        }

        // Cast as an array if not already
        if (is_array($data) === FALSE) {
            $data = (array) $data;
        }

        // Check if it's a multi-dimensional array
        if (isset($data[0]) && count($data) !== count($data, COUNT_RECURSIVE)) {
            // Multi-dimensional array
            $headings = array_keys($data[0]);
        } else {
            // Single array
            $headings = array_keys($data);
            $data = [$data];
        }

        // Apply the headings
        fputcsv($handle, $headings, $delimiter, $enclosure);

        foreach ($data as $record) {
            // If the record is not an array, then break. This is because the 2nd param of
            // fputcsv() should be an array
            if (is_array($record) === FALSE) {
                break;
            }

            // Suppressing the "array to string conversion" notice.
            // Keep the "evil" @ here.
            $record = @ array_map('strval', $record);

            // Returns the length of the string written or FALSE
            fputcsv($handle, $record, $delimiter, $enclosure);
        }

        // Reset the file pointer
        rewind($handle);

        // Retrieve the csv contents
        $csv = stream_get_contents($handle);

        // Close the handle
        fclose($handle);

        return $csv;
    }

}

?>