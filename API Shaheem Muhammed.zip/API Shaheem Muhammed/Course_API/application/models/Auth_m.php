<?php

class Auth_m extends CI_Model {

    function __construct() {
        $this->load->database();
        date_default_timezone_set('Asia/Calcutta');
    }

    //step1 model
    function auth_post($data) {
        $api_key = 0;
        $headers = apache_request_headers();

        //checking wther the API key sent or not in header
        if (array_key_exists('x-api-key', $headers)) {
            $api_key = $this->security->xss_clean($headers['x-api-key']);
        } else {

            $result = array('status' => false,
                'message' => 'API Key Missing',
                'response_code' => 400);
            return $result;
        }
        //cehcking weher the API key is valid or not
        $this->db->where('api_key', $api_key);
        $this->db->select('api_id,user_name,api_key');
        $query = $this->db->get('Table_api');
        if ($query->num_rows() == 1) {
            date_default_timezone_set('Asia/Calcutta');
            $dt = time();
            //session for 60 min
            $dte = strtotime("+60 minutes"); //valid for 1hrs
            $result['status'] = true;
            $result['message'] = 'Authentication Key Generated';
            $result['response_code'] = 200;
            $result['current_timestamp'] = $dt;
            $result['expiry_timestamp'] = $dte;
            $auth_key = $this->get_auth_key();
            $result['auth_key'] = $auth_key;
            $res = array(
                'apirequestlog_authkey' => $auth_key,
                'apirequestlog_starttime' => $dt,
                'apirequestlog_exptime' => $dte,
            );

            $this->db->insert('Table_apirequestlog', $res);
            return $result;
        } else {

            $result = array('status' => false,
                'message' => 'API Key is Not Valid',
                'response_code' => 400);
            return $result;
        }
    }

    private function get_auth_key() {
        $length = 32;
        $char = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ&0123456789';
        $auth_key = '';
        for ($i = 0; $i < $length; $i++) {
            $auth_key .= $char[rand(0, strlen($char) - 1)];
        }
        $auth_key = md5($auth_key . time());
        return $auth_key;
    }

}
