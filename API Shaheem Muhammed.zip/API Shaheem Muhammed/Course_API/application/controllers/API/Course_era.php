<?php

include(APPPATH . "libraries/Rest_controller.php");

class Course_era extends Rest_controller {

    public function __construct() {
        parent::Rest_controller();
        $this->load->model("Course_era_m");
    }

    /* step1:Authentication */

    function course_era_post() {

        //recieve the raw data
        $rawdata_post = file_get_contents('php://input');
        $message = $this->Course_era_m->course_era_post($rawdata_post);
        $this->response($message);
    }

}
