<?php

class Course_era_m extends CI_Model {

    function __construct() {
        $this->load->database();
        date_default_timezone_set('Asia/Calcutta');
    }

//step1 model
    function course_era_post($data) {

        $auth_key = 0;
        $headers = apache_request_headers();
        /* 1.checking wther the  auth_key sent or not in header */
        if (array_key_exists('auth_key', $headers)) {
            $auth_key = $this->security->xss_clean($headers['auth_key']);
        } else {

            $result = array('status' => false, 'message' => 'API Key Missing', 'response_code' => 400);
            return $result;
        }

        /* 2.check the enquiry data sent or not as raw data */
        if ($data) {
            $raw_data = $this->security->xss_clean($data);
        } else {

            $result = array('status' => false, 'message' => 'Data Missing', 'response_code' => 400);
            return $result;
        }

        /* 3.check the Authkey valid or not and key expired or not */
//*****************************************************************************************************************************************************sss
        $this->db->where('apirequestlog_authkey', $auth_key);
        $this->db->select('apirequestlog_id,apirequestlog_starttime,apirequestlog_exptime');
        $query = $this->db->get('Table_apirequestlog');

        if ($query->num_rows() == 1) {
            $req = $query->row();

            $reqres = array(
                'apirequestlog_id' => $req->apirequestlog_id,
                'apirequestlog_starttime' => $req->apirequestlog_starttime,
                'apirequestlog_exptime' => $req->apirequestlog_exptime,
            );
        } else {
            /* no auth key found */
            $result = array('status' => false, 'message' => 'Auth Key Not Found', 'response_code' => 400);
            return $result;
        }
        if ($this->auth_validate($reqres['apirequestlog_exptime']) == TRUE) {
            /* valid auth key so continue the process */
        } else {

            /* server session Expired */
            $result = array('status' => false, 'message' => 'Server Session Expired', 'response_code' => 403);
            return $result;
        }


        /* 4. parse the recieved Raw data in JSON  format */
        $json_data = (json_decode($raw_data, true));
        $count = count($json_data['elements']);

//        print_r($json_data );die;
        for ($i = 0; $i < $count; $i++) {

            if (isset($json_data['elements'][$i]['courseType'])) {
                $type = $json_data['elements'][$i]['courseType'];
            } else {
                $result = array('status' => false, 'message' => 'Input Missing', 'desc' => 'courseType', 'response_code' => 400);
                return $result;
            }

            if (isset($json_data['elements'][$i]['id'])) {
                $id = $json_data['elements'][$i]['id'];
            } else {
                $result = array('status' => false, 'message' => 'Input Missing', 'desc' => 'id', 'response_code' => 400);
                return $result;
            }

            if (isset($json_data['elements'][$i]['name'])) {
                $name = $json_data['elements'][$i]['name'];
            } else {
                $result = array('status' => false, 'message' => 'Input Missing', 'desc' => 'name', 'response_code' => 400);
                return $result;
            }


            $check_id = $this->courseexist_check($id);

            if ($check_id == FALSE) {

                $course_id = $this->course_insert($id, $type, $name);
                $result = array('status' => true, 'message' => ' Successful', 'response_code' => 200);
            } else {
                $result = array('status' => false, 'message' => 'Error Occured! Already Exist', 'response_code' => 400);
            }
        }
        //trigger mail
        return $result;
    }

    private function courseexist_check($id) {
        $this->db->select('c_tableid');
        $this->db->where('course_id', $id);
        $query = $this->db->get('Course');
        if ($query->num_rows() == 1) {
            $row = $query->row();
            return $row->c_tableid;
        } else {
            return FALSE;
        }
        return FALSE;
    }

    private function course_insert($id, $type, $name) {

        $datetime = date('Y-m-d H:i:s');
        $course_data = array(
            'course_id' => $id,
            'course_type' => $type,
            'course_name' => $name,
        );
        $this->db->insert('Course', $course_data);
        $course_id = $this->db->insert_id();
        return $course_id;
    }

    private function auth_validate($request_exptime) {


        date_default_timezone_set('Asia/Calcutta');
        $now = time();

        if ($now < $request_exptime) {

            return TRUE;
        } else {
            return FALSE;
        }
    }

}
