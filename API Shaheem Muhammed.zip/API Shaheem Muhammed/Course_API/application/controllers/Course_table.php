<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Course_table extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->database();
    }

    public function index() {
        $query = $this->db->get('Course');
        $tab = $query->result();
        $i = 1;
        echo "<table>";
        echo "<tr>";
        echo "<th>SI No.</th>";
        echo "<th>Course ID</th>";
        echo "<th>Course Name</th>";
        echo "<th>Course Type</th>";

        echo "</tr>";
        foreach ($tab as $tabs) {
            echo "<tr>";
            echo "<td>" . $i++ . "</td>";
            echo "<td>" . $tabs->course_id . "</td>";
            echo "<td>" . $tabs->course_name . "</td>";
            echo "<td>" . $tabs->course_type . "</td>";

            echo "</tr>";
        }
        echo "</table>";
    }

}
